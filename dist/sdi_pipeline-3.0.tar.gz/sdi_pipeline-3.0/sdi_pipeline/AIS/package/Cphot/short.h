#define   short_type  unsigned short
#define   swap_flag   1
#define   DATA_TYPE double
