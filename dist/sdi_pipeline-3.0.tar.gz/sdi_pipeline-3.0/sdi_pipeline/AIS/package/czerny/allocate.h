 complex_mat Phi,ph,phm1,z,temp1,temp2,temp3,q;
