extern void allocate(),init(),add(),sub(),mult(),mult_conj()
       ,cmult(),copy();
 extern complex scal_prod(),comp_div();
