

	extern void fit(double *,double *,double *,int,int,double *,int);
        extern void nnerror();
	extern double poly(),sigma();
