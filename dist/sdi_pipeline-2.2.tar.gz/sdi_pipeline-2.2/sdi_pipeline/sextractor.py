import sex

if __name__ == '__main__':
    path = input("Enter path to target's exposure time directory: ")
    sex.sex(path)